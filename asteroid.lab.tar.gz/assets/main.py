import pygame
import random
import math
import asyncio


pygame.init()

WIDTH = 600
HEIGHT = 400

NUM = 3
MISSILE_SPEED = 7
SHIP_RADIUS = 8
game_over = False

RED = (255, 0, 0)
GRAY = (186, 181, 181)
WHITE = (255, 255, 255)

screen = pygame.display.set_mode ((WIDTH, HEIGHT))
pygame.display.set_caption ("Crazy Asteroids")
clock = pygame.time.Clock()
font = pygame.font.Font(None, 30)

#asteroid class

class Asteroid:
    def __init__(self):
        self.radius = random.randint( 10, 30)

        self.position = pygame.Vector2(
            random.randint (self.radius, WIDTH - self.radius),
            random.randint (self.radius, HEIGHT - self.radius)
        )

        
        

        angle = random.uniform (0, 2 * math.pi)

        speed = random.uniform (1.5, 3.0)

        self.velocity = pygame.Vector2(
            math.cos (angle),
            math.sin (angle),
        ) *speed

    def update (self):
        #screen teleporting
        self.position += self.velocity



        if self.position.x > WIDTH + self.radius:
            self.position.x = -self.radius

        if self.position.x < -self.radius:
            self.position.x = WIDTH + self.radius

        if self.position.y > HEIGHT + self.radius:
            self.position.y = -self.radius

        if self.position.y < -self.radius:
            self.position.y = HEIGHT + self.radius

    def draw (self):
        pygame.draw.circle (
            screen, 
            GRAY, 
            (int(self.position.x), 
            int(self.position.y)),
            self.radius
        )

#missile class
class Missile:
    def __init__ (self, start_position, target_position):
        self.position = pygame.Vector2 (start_position)
        self.radius = 5


        direction = pygame.Vector2(target_position) - self.position
        if direction.length() != 0:
            direction = direction.normalize() 
        #unit vector
        self.velocity = direction * MISSILE_SPEED

    def update (self):
        self.position += self.velocity

    def draw (self):
        pygame.draw.circle (
            screen,
            WHITE, 
            (int(self.position.x), int(self.position.y)),
            self.radius
        )

    def off_screen (self):
        return (
            self.position.x < 0 or
            self.position.x > WIDTH or
            self.position.y < 0 or
            self.position.y > HEIGHT
        )

class Enemy:
    def __init__(self, position, speed):
        self.position = pygame.Vector2(position)
        self.speed = speed
        self.radius = 12
        self.angle = 0
        self.forward = pygame.Vector2(1, 0)

        self.detection_range = 150
        self.fov_threshold = 0.5
        self.detected = False


    def update(self, player_position):
        #facing direction
        radians = math.radians(self.angle)

        self.forward = pygame.Vector2(
            math.cos(radians), -math.sin(radians)
        )
        #calculate direction and distance to player
        to_player = pygame.Vector2(player_position) - self.position
        self.distance = to_player.length()

        if to_player.length() > 0:
            to_player = to_player.normalize()

        self.dot = self.forward.dot(to_player)

        self.detected = (self.distance < self.detection_range and 
                        self.dot > self.fov_threshold
        )

    def draw(self):
        color = RED if self.detected else WHITE

        left = self.forward.rotate(140)
        right = self.forward.rotate(-140)

        p1 = self.position + self.forward * 16   # nose
        p2 = self.position + left * 12           # back left
        p3 = self.position + right * 12          # back right

        pygame.draw.polygon(screen, color, [p1, p2, p3], 2)
        pygame.draw.circle(
            screen,
            GRAY,
            enemy.position,
            self.detection_range,
            1
        )
        pygame.draw.line(
            screen,
            RED,
            enemy.position,
            enemy.position + self.forward * 100,
            3
        )




#draw ship
def draw_ship (position):
    x = int(position.x)
    y = int(position.y)

    front = ship_position + forward *20
    left = forward.rotate(140)
    right = forward.rotate(-140)


    p1 = ship_position + forward * 11
    p2 = ship_position + left * 8
    p3 = ship_position + right * 8

    pygame.draw.polygon(
        screen,
        "white",
        [p1, p2, p3],
        2
    )
    pygame.draw.circle (screen, WHITE, (int(position.x), int(position.y)), 2)

def missile_hits_asteroid (missile, asteroid):
    distance = missile.position.distance_to (asteroid.position)
    return distance < (missile.radius + asteroid.radius)

def ship_hits_asteroid (ship_position, asteroid):
    distance = ship_position.distance_to (asteroid.position)
    return distance < (SHIP_RADIUS + asteroid.radius)



ship_position = pygame.Vector2 (WIDTH // 2, HEIGHT // 2)
ship_angle = 90
ROTATION_SPEED = 2
THRUST = 0.10
SHIP_SPEED = 2
MAX_SPEED = 4
DRAG = 0.99
VELOCITY = pygame.Vector2(0, 0)




#game objects

asteroids = []

for i in range (NUM):
    asteroids.append (Asteroid())

missiles = []
score = 0
enemy = Enemy((WIDTH / 4, HEIGHT / 2), 1.5)


async def main():
    global game_over, ship_position, ship_angle, VELOCITY
    global asteroids, missiles, score, forward

    running = True
    #game loop


    while running:
        clock.tick (60)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.MOUSEBUTTONDOWN:
                target_position = pygame.Vector2 (event.pos)
                new_missile = Missile (ship_position, target_position)
                missiles.append (new_missile)


        if game_over:
            screen.fill((0, 0, 0))

            title = font.render("GAME OVER", True, RED)
            title_rect = title.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 30))
            screen.blit(title, title_rect)

            info = font.render(
                "Score: " + str(score) + "     Press R to restart", True, WHITE
            )
            info_rect = info.get_rect(center=(WIDTH // 2, HEIGHT // 2 + 40))
            screen.blit(info, info_rect)

            pygame.display.flip()

            keys = pygame.key.get_pressed()
            if keys[pygame.K_r]:
                ship_position = pygame.Vector2(WIDTH // 2, HEIGHT // 2)
                VELOCITY = pygame.Vector2(0, 0)
                asteroids = [Asteroid() for _ in range(NUM)]
                missiles = []
                score = 0
                game_over = False

            await asyncio.sleep(0)
            continue


        keys = pygame.key.get_pressed()
        if keys [pygame.K_LEFT]:
            ship_angle += ROTATION_SPEED
        if keys [pygame.K_RIGHT]:
            ship_angle -= ROTATION_SPEED

        radians = math.radians (ship_angle)

        forward = pygame.Vector2 (
        math.cos (radians),
        -math.sin (radians)
        )

        acceleration = pygame.Vector2(0, 0)

        if keys [pygame.K_UP]:
            ship_position += forward * SHIP_SPEED
            acceleration = forward * THRUST

    

        if VELOCITY.length() > MAX_SPEED:
            VELOCITY.scale_to_length(MAX_SPEED)

        VELOCITY += acceleration
        ship_position += VELOCITY
        VELOCITY *= DRAG

        ship_position.x %= WIDTH
        ship_position.y %= HEIGHT

        enemy.angle += 1          
        enemy.update(ship_position)
        
        #update asteroids
        for asteroid in asteroids:
            asteroid.update()
            if ship_hits_asteroid(ship_position, asteroid):
                game_over = True

        for missile in missiles:
            missile.update()

        keys = pygame.key.get_pressed()
        if keys[pygame.K_r]:
            ship_position = pygame.Vector2(WIDTH // 2, HEIGHT // 2)
            VELOCITY = pygame.Vector2(0, 0)
            asteroids = [Asteroid() for _ in range(NUM)]
            missiles = []
            score = 0
            game_over = False

        missiles = [
            missile for missile in missiles if not missile.off_screen()
        ]

        for missile in missiles[:]:

            for asteroid in asteroids[:]:

                if missile_hits_asteroid(missile, asteroid):

                    # Remove the missile
                    if missile in missiles:
                        missiles.remove(missile)

                    # Remove the asteroid
                    if asteroid in asteroids:
                        asteroids.remove(asteroid)

                    # Create a new asteroid
                    asteroids.append(Asteroid())

                    score += 1

                    break



        #draw
        screen.fill ((0, 0, 0))

        

        draw_ship(ship_position)

        enemy.draw()

        if enemy.detected:
            status = font.render("Enemy: PLAYER DETECTED!", True, RED)
        else:
            status = font.render("Enemy: PATROL", True, WHITE)
        screen.blit(status, (15, 65))

        for asteroid in asteroids:
            asteroid.draw()

        for missile in missiles:
            missile.draw()

        instruction = font.render(
            "Click to shoot missiles at asteroids",
            True,
            WHITE
        )
        screen.blit(instruction, (15, 15))

        score_text = font.render("Score:" + str(score), True, WHITE)
        screen.blit (score_text, (15, 40))

        formula = font.render(
            "direction = target - position   ->   normalize   ->   x speed",
            True,
            GRAY
        )

        screen.blit(formula, (20, HEIGHT - 35))

        pygame.display.flip()

        await asyncio.sleep(0)

    pygame.quit()

asyncio.run(main())

